/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phonebook;

public class Contact {
    public String Name, Ct_No;

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getCt_No() {
        return Ct_No;
    }

    public void setCt_No(String Ct_No) {
        this.Ct_No = Ct_No;
    }
    public String toString() 
    {
        StringBuffer buffer = new StringBuffer();
        buffer.append(Name);
        return buffer.toString();
    }

}
